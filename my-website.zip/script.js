function showAlert() {
    alert('Button clicked!');
}
